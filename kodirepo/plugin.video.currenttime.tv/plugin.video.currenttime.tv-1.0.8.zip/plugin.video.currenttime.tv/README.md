# plugin.video.currenttime.tv

KODI add-on for watching Current Time TV channel - live stream, video and tvshows archive 

Плагин KODI для просмотра ТВ канала "Настоящее Время" (currenttime.tv) - прямого эфира, записей телепрограмм и видео
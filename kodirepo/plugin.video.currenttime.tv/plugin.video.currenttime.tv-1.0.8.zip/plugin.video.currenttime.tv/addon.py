# -*- coding: UTF-8 -*-
import sys
import os
import urllib
import urlparse
import urllib2
import re
import threading
import Queue
import datetime
import time
import xbmc, xbmcgui, xbmcaddon, xbmcplugin

stream_url = {
    '1080p':'http://rfe-lh.akamaihd.net/i/rfe_tvmc5@383630/index_1080_av-p.m3u8',
    '720p': 'http://rfe-lh.akamaihd.net/i/rfe_tvmc5@383630/index_0720_av-p.m3u8',
    '540p': 'http://rfe-lh.akamaihd.net/i/rfe_tvmc5@383630/index_0540_av-p.m3u8',
    '404p': 'http://rfe-lh.akamaihd.net/i/rfe_tvmc5@383630/index_0404_av-p.m3u8',
    '288p': 'http://rfe-lh.akamaihd.net/i/rfe_tvmc5@383630/index_0288_av-p.m3u8'
}
video_url = {
    '720p': '_hq.mp4',
    '360p': '.mp4',
    '270p': '_mobile.mp4'
}
video_url = {
    '1080p': 'index_3_av.m3u8',
     '720p': 'index_2_av.m3u8',
     '360p': 'index_1_av.m3u8',
     '270p': 'index_0_av.m3u8'
}

main_menu = ([
    [30003, 30004, 'lastvids+next', 	'folder',       '/z/17317'],   #Broadcasts
#    [30005, 30006, 'tvshows',			'folder',       ''],           #TV Shows #fivesubjects: disabling this line, new extended functionality bellow
    [30005, 30006, 'tvshowsNG',			'folder',       '/program'],           #TV Shows fivesubjects: New Generation
    [30007, 30008, 'lastvids+next', 	'folder',       '/z/17192'],   #All Videos
    [30009, 30010, 'lastvids+next', 	'folder',       '/snapshot'],   #Daily Shoots
    [30011, 30012, 'lastvids+next', 	'folder',       '/report'],   #Reportages
    [30013, 30014, 'lastvids+next', 	'folder',       '/interview'],   #Interviews
    [30906, 30907, 'lastvids+archive', 	'folder',       '/doc'],   #Documentaries
    [30015, 30016, 'schedule',          'folder',       '/schedule/tv/92#live-now']   # TV Listing
])
tvshows = ([
    [30031, 30032, 'lastvids+archive',  'olevski',	    '/z/20333'],
    [30033, 30034, 'lastvids+archive',  'nveurope',     '/z/18657'],
    [30035, 30036, 'lastvids+archive',  'nvasia', 	    '/z/17642'],
    [30037, 30038, 'lastvids+archive',  'nvamerica',    '/z/20347'],
    [30039, 30040, 'lastvids+archive',  'oba', 		    '/z/20366'],
    [30041, 30042, 'lastvids+archive',  'itogi', 	    '/z/17499'],
    [30043, 30044, 'lastvids+archive',  'week',		    '/z/17498'],
    [30045, 30046, 'lastvids+archive',  'baltia', 	    '/z/20350'],
    [30047, 30048, 'lastvids+archive',  'bisplan', 	    '/z/20354'],
    [30049, 30050, 'lastvids+archive',  'unknownrus',   '/z/20331'],
    [30051, 30052, 'lastvids+archive',  'guests', 	    '/z/20330'],
])


mask_url = '</a>\n<div class="content">\n' \
           '<span class="date" ?>.+?</span>\n' \
           '<a href="(.+?)"'


mask_date_url = '''<img data-src="(.+?)" src="" alt="(.+?)">
</div>
<span class="ico ico-video ico--media-type"></span>
</a>
<div class="content">
<span class="date" ?>(.+?)</span>
<a href="(.+?)"'''

mask_video_url = '<video poster=".+?" src="(.+?)" data-fallbacksrc=".+?" data-fallbacktype="video/mp4"'
mask_video_img = '<video poster="(.+?)"'
mask_video_title = '<meta name="title" content="(.+?)"'
mask_video_plot = '<meta name="description" content="(.+?)" />'
mask_video_date = '''<div class="published">
<span class="date" >
<time datetime="(.+?)">
.+?
</time>
</span>
</div>'''


mask_programme_block =  '<li class="col-xs-12 col-sm-12 col-md-12 col-lg-12">\n'\
                        '(.+?' \
                        '\n</li>\n' \
                        '.+?' \
                        '\n</div><a class="link-more" href=".+?">.+?</a>)\n' 
mask_programme_title =  '<span class="title">(.+?)</span>\n'
mask_programme_plot =   '<p class="perex">(.+?)</p>'
mask_programme_img =    '<noscript class="nojs-img">\n' \
                        '<img src="(.+?)" alt=".+?">\n' \
                        '</noscript>\n'
mask_programme_url =    '<a class="link-more" href="(.+?)">.+?</a>'
mask_programme_supertitle = r'^([^.:]+?[:.])(.+?)|(^.+?)$'                        
mask_programme_supertitle = r'^([^.:]+?)([:.].+?)$'                        

mask_schedule = '<div class="time-stamp">\n' \
                '<span class="date date--time" >(.+?)</span>\n' \
                '</div>\n' \
                '<div class="img-wrap">\n' \
                '<div class="thumb thumb16_9">\n' \
                '<noscript class="nojs-img">\n' \
                '<img src="(.+?)" alt=" ">\n' \
                '</noscript>\n' \
                '<img data-src=".+?" src="" alt=" ">\n' \
                '.+?' \
                '<div class="content">\n' \
                '<h4 class="media-block__title">\n' \
                '(.+?)\n' \
                '</h4>\n' \
                '<p>(.+?)</p>\n'
mask_schedule_online = '<span class="badge badge--live" >.+?</span>\n'

NUM_OF_PARALLEL_REQ = 6    #queue size
MAX_REQ_TRIES = 3
MAX_ITEMS_TO_SHOW = 12

base_url = None
addon_handle = None
folder_url = None
folder_title = None
folder_level = None
folder_name = None

site_url = 'https://www.currenttime.tv'
addon_name = 'plugin.video.currenttime.tv'
addon = xbmcaddon.Addon(addon_name)
addon_icon = addon.getAddonInfo('icon')

def parseRussianDate(dateStr):
    """Parses dates in the format used on the website"""
    return dateStr


def checkURLold(url):
    """Checks if the URL is valid"""
    try: urllib.request.urlopen(url)
    except: return False
    return True

def checkURL(url):
    #returnCode=requests.get(url).status_code
    try:
        returnCode = urllib2.urlopen(url).getcode()
        if (returnCode == 200 ):
            print('URL {} exists.'.format(url))
            return True
        else:
            print('Unknown return code retrieving {}: {}'.format(url, returnCode))
            return False
    except urllib2.URLError as e:
            print('HTTPError retrieving {}: [{}] {}'.format(url, e.code, e.reason))
            return False
    except:
            print('Unknown error retrieving {}'.format(url))
            return False

def build_video_url(original_m3u, preferedQuality):
    """Builds a url based on the original m3u8 file and the prefered quality supplied"""
    global video_url
    return re.sub(r'(.+?/)master.m3u8', r'\1', original_m3u)+video_url[preferedQuality]


def selectArchiveStream(m3u, preferedQuality):
    """Selects the stream most closely matching the prefered quality"""
    global video_url
    #import rpdb2 ; rpdb2.start_embedded_debugger('pw') #TODO: Remove me
    #import web_pdb; web_pdb.set_trace() #TODO: Remove me
    if (
        re.compile('1080p').match(preferedQuality)
        and checkURL(build_video_url(m3u, '1080p') )
    ):
        return build_video_url(m3u, '1080p')
    elif (
        re.compile('720p|1080p').match(preferedQuality)
        and checkURL(build_video_url(m3u, '720p') )
    ):
        return build_video_url(m3u, '720p')
    elif (
        re.compile('360p|720p|1080p').match(preferedQuality)
        and checkURL(build_video_url(m3u, '360p') )
    ):
        return build_video_url(m3u, '360p')
    else :
        return build_video_url(m3u, '270p')


def offset2localtime(hhmm_hhmm):
    """Offsets the time in Moscow timezone accordingly to match the corresponsing time in the local timezone"""
    #import rpdb2 ; rpdb2.start_embedded_debugger('pw') #TODO: Remove me
    #import web_pdb; web_pdb.set_trace() #TODO: Remove me
    
    moscow_utc_offset_hours = 3.0 #Russia has abandoned DST, so the offset is always constant
    local_is_dst = time.daylight and time.localtime().tm_isdst > 0
    local_utc_offset_hours = - (time.altzone if local_is_dst else time.timezone)/3600
    moscowtz_offset_hours=moscow_utc_offset_hours - local_utc_offset_hours
    
    hhmm_hhmm = re.compile(r'(\d+):(\d+) - (\d+):(\d+)').findall(hhmm_hhmm)
    now = datetime.datetime.now()
    timedelta = datetime.timedelta(hours=moscowtz_offset_hours)
    timeFrom = datetime.datetime(now.year, now.month, now.day, int(hhmm_hhmm[0][0]), int(hhmm_hhmm[0][1]), 0, 0) - timedelta
    timeTo = datetime.datetime(now.year, now.month, now.day, int(hhmm_hhmm[0][2]), int(hhmm_hhmm[0][3]), 0, 0) - timedelta
    return(timeFrom.strftime('%H:%M') + ' - ' + timeTo.strftime('%H:%M'))


def cleanhtml(html):
    """Removes html tags from data or list"""
    cleanr = re.compile('<.*?>')
    return cleanr.sub('', html)


def build_page_link(folder_url, folder_level, next=False):
    """"Builds reference to next page if required"""
    page = (folder_level - 1 ) if next == False else folder_level
    if page > 0:
        page = '?p=' + str(page)
    else:
        page = ''
    return folder_url + page


def img_link(name, type):
    """"builds full image path with given name and ext."""
    if type == 'fanart' or type == 'poster':
        ext = '.jpg'
    else:
        ext = '.png'
    return os.path.join(addon.getAddonInfo('path'), "resources/media/" + name + '_' + type + ext)


def add_dir(arg):
    """adds dir item by given in arg parameters"""
    li = xbmcgui.ListItem(label=arg['title'])
    if arg['mode'] != 'play':
        arg['url'] = base_url + '?'\
                     + urllib.urlencode({'mode': arg['mode'], 'title': arg['title'], 'name': arg['name'],
                                         'level': str(folder_level + 1), 'folderurl': arg['url']})
        isFolder = True
        li.setProperty("IsPlayable", "false")  # !!!
    else:
        isFolder = False
        li.setProperty("IsPlayable", "true")  # !!!
    info = {
        'mediatype': 'video',                 # !!!
        'plot': arg['plot'],
        'Title': arg['title']
    }
    if 'date' in arg:
    #    xbmc.Log(arg['date'])
        info['aired'] = arg['date']
        li.setLabel('[B]'+arg['date'][0:10]+'[/B] ' + arg['title'])
    li.setInfo('video', info)
    li.setArt({'thumb': arg['thumb'], 'fanart': arg['fanart']})
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=arg['url'], listitem=li, isFolder=isFolder)
    return ok


def get_video_dir(page):
    """creates playable dir item after parsing page with video for corresponding details """
    try:
        if page is None:
            raise Exception
        match_url = re.compile(mask_video_url).findall(page)
        match_img = re.compile(mask_video_img).findall(page)
        match_title = re.compile(mask_video_title).findall(page)
        match_plot = re.compile(mask_video_plot).findall(page)
        match_date = re.compile(mask_video_date).findall(page)
        if len(match_plot) < 1:
            match_plot = [' ']
        return {
            'name':     folder_name,
            'thumb':    make_thumb_url(match_img[0]),
            'fanart':   make_fanart_url(match_img[0]),
            'mode':     'play',
            'title':    re.sub('&.{0,5};', clean_txt, match_title[0]),
            'plot':     re.sub('&.{0,5};', clean_txt, cleanhtml(match_plot[0]) ),
            'url':      selectArchiveStream(match_url[0], xbmcplugin.getSetting(addon_handle, 'res_video') ),
            'date':     match_date[0]
        }
    except:
        return None


def generate_programmes_menu(folder_url):
    """Creates menu by parsing the page with programmes """
    #Get the index
    programmes_url = site_url + folder_url
    page = read_page(programmes_url)
    #import rpdb2 ; rpdb2.start_embedded_debugger('pw') #TODO: Remove me
    #import web_pdb; web_pdb.set_trace() #TODO: Remove me
    try:
        if page is None:
            raise Exception
        # First matches individual programme blocks
        match_blocks = re.compile(mask_programme_block, re.DOTALL).findall(page)
        # Next matches information inside the blocks
        for block in match_blocks:
            title = re.compile(mask_programme_title).findall(block)
            plot = re.compile(mask_programme_plot).findall(block)
            img = re.compile(mask_programme_img).findall(block)
            url = re.compile(mask_programme_url).findall(block)
            if len(plot) < 1:
                plot = [' ']
            if len(title) < 1:
                title = [' ']
            
            # Formats programe title in bold
            if (re.compile(mask_programme_supertitle).match(title[0]) ):
                title = re.sub(mask_programme_supertitle, r'[B]\1[/B]\2', title[0])
            else:
                title = '[B]' + title[0] + '[/B]'
        
            # Processes url to a canonical state
            url = url[0].replace('https://www.currenttime.tv', '')
            url = url.replace('www.currenttime.tv', '')
            if( url == '/p/7363.html' ):
                # Exception, page is unique layout, change the original of the archive
                url = '/z/20708'
                mode = 'lastvids+archive'
            if ( url == '/p/6668.html' ): # Ladies football
                # Has no video, jump/continue
                continue
            elif (url.find('html') > 0 or re.compile(r'/[A-z]{0}/[A-z0-9]+').match(url) ) :
                #is not an archive
                mode = 'lastvids+next'
            elif( url.find('episodes') == -1 ) :
                url = url + '/episodes'
                mode = 'lastvids+archive'
            else :
                mode = 'lastvids+archive'
            
            add_dir({
                'name': url,
                'title': re.sub('&.{0,5};', clean_txt, title), #title[0]),
                'plot': re.sub('&.{0,5};', clean_txt, plot[0]),
                'url': url,
                'mode': mode,
                'thumb': make_thumb_url(img[0]),
                'fanart': make_fanart_url(img[0])
            })
        xbmcplugin.endOfDirectory(addon_handle)

    except:
        return None


def clean_txt(str_to_clean):
    """clean html mess from str, replace things like '&#code;' with corresponding symbol"""
    try:
        #remove first and last chars ('&' and ';')
        str = str_to_clean.group(0)[1:-1]
        # remove '#' if there is one
        str = re.sub('#', '', str)
        if str == ('quot' or 'QUOT'):
            return '"'
        if str == ('39'):
            return "'"
        return unichr(int(str)).encode('utf8')
    except:
        return ''


def get_video_page_thread(page_url, where_to_put, index_to_put):
    """requests page and stores it in list 'where_to_put[index_to_put]'"""
    where_to_put[index_to_put] = get_video_dir(read_page(page_url))
    queue.get(True, None)
    queue.task_done()


def read_page(page_url, tries=MAX_REQ_TRIES):
    """request page by 'page_url' and returns it, if request fails 'tries' times returns None"""
    req = urllib2.Request(page_url)
    req.add_header('User-Agent',
                   ' Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    for t in range(0, tries):
        try:
            response = urllib2.urlopen(req, timeout=3)
            page = response.read()
            response.close()
            return page
        except:
            xbmc.sleep(1000)
    return None


def generate_menu(menu):
    """generates menu with dir items' parameters stored in 'menu' list"""
    for title, plot, mode, name, url in menu:
        add_dir({
            'name':    name,
            'thumb':   img_link(name, 'thumb'),
            'fanart':  img_link(name, 'fanart'),
            'mode':    mode,
            'title':   string(title),
            'plot':    string(plot),
            'url':     url
        })
    xbmcplugin.endOfDirectory(addon_handle)


def get_stream_url():
    """generates online stream url"""
    return stream_url[xbmcplugin.getSetting(addon_handle, 'res_stream')]


def make_thumb_url(url):
    """generates url to thumbnail pic"""
    thumb = ''
    if xbmcplugin.getSetting(addon_handle, 'download_thumbnails') == 'true':
        thumb = re.sub(r'_w\w+', '_w512_r1', url)
    return thumb


def make_fanart_url(url):
    """generates url to fanart pic"""
    fanart = ''
    if xbmcplugin.getSetting(addon_handle, 'download_fanart') == 'true':
        fanart = re.sub(r'_w\w+', '_w1920_r1', url)
    return fanart


def match_in_page(url, mask):
    return re.compile(mask, re.DOTALL).findall(read_page(url))


def string(code):
    return addon.getLocalizedString(code).encode('utf-8')


def generate_videolinks_menu(match_url):
    video_pages_buffer = [None] * len(match_url)
    global queue
    queue = Queue.Queue(NUM_OF_PARALLEL_REQ)
    for i, url in enumerate(match_url):
        queue.put(1, True, None)
        t = threading.Thread(target=get_video_page_thread, args=(site_url + url, video_pages_buffer, i))
        t.daemon = True
        t.start()
    # now block and wait until all request tasks are done
    queue.join()
    for video_page in video_pages_buffer:
        if video_page is not None:
            add_dir(video_page)


def addon_main(bs_url, addon_hndl, addon_url):
    global base_url
    global addon_handle
    global mode
    global folder_url
    global folder_title
    global folder_level
    global folder_name
    base_url = bs_url
    addon_handle = int(addon_hndl)
    xbmcplugin.setContent(addon_handle, 'videos')
    print("addon.py addon url:" + addon_url)    #!!!!!!!!!!!!!!!!!!
    args = urlparse.parse_qs(addon_url[1:])
    mode = args.get('mode', [None])[0]
    folder_url = args.get('folderurl', [None])[0]
    folder_title = args.get('title', [None])[0]
    folder_level = int(args.get('level', '0')[0])
    folder_name = args.get('name', [None])[0]

    ### Main menu
    if mode is None:
        mode = ['main_menu']
        add_dir({
            'name': 'live',
            'thumb': img_link('live', 'thumb'),
            'fanart': img_link('live', 'fanart'),
            'mode': 'play',
            'title': '[B]' + string(30001) + '[/B]',
            'plot': string(30002),
            'url': get_stream_url(),
        })
        generate_menu(main_menu)

    ### TV Programmes menu
    elif mode == 'tvshows':
        generate_menu(tvshows)

    ### TV Programmes menu - New Generation
    elif mode == 'tvshowsNG': 
        generate_programmes_menu(folder_url)

    ### List videos with NEXT link
    elif mode == 'lastvids+next':
        match_url = match_in_page(site_url + build_page_link(folder_url, folder_level, False), mask_url)
        generate_videolinks_menu(match_url)
        # add menu item 'Next'
        add_dir({
            'name': folder_name,
            'thumb': img_link('folder', 'thumb'),
            'fanart': img_link(folder_name, 'fanart'),
            'mode': 'lastvids+next',
            'title': 'lvn [B]>> ' + string(30101)
                     + '... (' + str(folder_level + 1) + ')[/B]',  # Next
            'plot': string(30102),
            'url': folder_url
        })
        xbmcplugin.endOfDirectory(addon_handle)

    ### List videos with ARCHIVE link
    elif mode == 'lastvids+archive':
        #import rpdb2 ; rpdb2.start_embedded_debugger('pw') #TODO: Remove me
        #import web_pdb; web_pdb.set_trace() #TODO: Remove me
        match_date_url = match_in_page(site_url + build_page_link(folder_url, folder_level-1, False), mask_date_url)
        video_pages_buffer = [None] * len(match_date_url)
        global queue
        queue = Queue.Queue(NUM_OF_PARALLEL_REQ)
        i=0
        for img, title, date, url in match_date_url:
            queue.put(1, True, None)
            t = threading.Thread(target=get_video_page_thread, args=(site_url + url, video_pages_buffer, i))
            t.daemon = True
            t.start()
            i = i+1
        # now block and wait until all request tasks are done
        queue.join()
        for video_page in video_pages_buffer:
            if video_page is not None:
                add_dir(video_page)

        """for img, title, date, url in match_date_url:
            add_dir({
                'name': folder_name,
                'thumb': make_thumb_url(img),
                'fanart': make_fanart_url(img),
                'mode': 'video',
                'title': 'lvaNG [B]' + date + '[/B]  ' + re.sub('&.{0,5};', clean_txt, title),  # +' | '+folder_title,
                'plot': re.sub('&.{0,5};', clean_txt, title),
                'url': url
            })"""

		# add menu item 'Next'
        add_dir({
            'name': folder_name,
            'thumb': img_link('folder', 'thumb'),
            'fanart': img_link(folder_name, 'fanart'),
            'mode': 'lastvids+archive',
            'title': '[B]>> ' + string(30101)
                     + '... (' + str(folder_level ) + ')[/B]',  # Next
            'plot': string(30102),
            'url': folder_url
        })
        xbmcplugin.endOfDirectory(addon_handle)

    ### List videos with ARCHIVE link
    elif mode == 'lastvids+archive_old':
        match_date_url = match_in_page(site_url + build_page_link(folder_url, folder_level-1, False), mask_date_url)
        for img, title, date, url in match_date_url:
            add_dir({
                'name': folder_name,
                'thumb': make_thumb_url(img),
                'fanart': make_fanart_url(img),
                'mode': 'video',
                'title': 'lva [B]' + date + '[/B]  ' + re.sub('&.{0,5};', clean_txt, title),  # +' | '+folder_title,
                'plot': re.sub('&.{0,5};', clean_txt, title),
                'url': url
            })

		# add menu item 'Next'
        add_dir({
            'name': folder_name,
            'thumb': img_link('folder', 'thumb'),
            'fanart': img_link(folder_name, 'fanart'),
            'mode': 'lastvids+archive',
            'title': '[B]>> ' + string(30101)
                     + '... (' + str(folder_level ) + ')[/B]',  # Next
            'plot': string(30102),
            'url': folder_url
        })
        xbmcplugin.endOfDirectory(addon_handle)

    ### List ONE video from archive
    elif mode == 'video':
        add_dir(get_video_dir(read_page(site_url + folder_url)))
        xbmcplugin.endOfDirectory(addon_handle)

    ### TV Listing for today
    elif mode == 'schedule':
        currentListItem = 2
        toFocus = 2
        match = match_in_page(site_url + folder_url, mask_schedule)
        for time, img_url, name, descrip in match:
            online = re.match(mask_schedule_online, name)
            url = ''
            mode = 'folder'
            if online is None:
                title = '[B]' + offset2localtime(time) + '[/B]  ' + name
            else:
                title = '[B][COLOR red][UPPERCASE]' + offset2localtime(time) + ' ' + string(30001) \
                        + '[/UPPERCASE][COLOR blue]   ' + name[online.span()[1]:] + '[/COLOR][/B]'
                url = get_stream_url()
                mode = 'play'
                toFocus = currentListItem
            add_dir({
                'name': folder_name,
                'thumb': make_thumb_url(img_url),
                'fanart': make_fanart_url(img_url),
                'mode': mode,
                'title': re.sub('&.{0,5};', clean_txt, title),
                'plot': re.sub('&.{0,5};', clean_txt, descrip),
                'url': url
            })
            currentListItem = currentListItem + 1
        xbmcplugin.endOfDirectory(addon_handle)
        win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
        cid = win.getFocusId()
        xbmc.executebuiltin('SetFocus(%s, %s)' % (cid, toFocus))
        

if __name__ == "__main__":
    try:
        addon_main(sys.argv[0], sys.argv[1], sys.argv[2])
    except Exception as e:
        xbmcgui.Dialog().notification(addon_name, string(30801), addon_icon)
